﻿using System;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Area a = new Area();
            a.CalcArea();
            DollerRupees dr = new DollerRupees();
            dr.DollToRup();
            dr.RupToDoll();
            Ascii asc = new Ascii();
            asc.AsciiValue();
            Console.ReadLine();
        }
    }

    class Area
    {
        public void CalcArea() //Calculate Area Of Circle
        {
            Console.WriteLine("::::::: PROGRAM : AREA OF CIRCLE ::::::");
            const double pi = 3.14;
            Console.WriteLine("Enter Value Of Radius : ");
            int r = Convert.ToInt32(Console.ReadLine());
            double area = r * r * pi;
            Console.WriteLine("Area Of Circle : {0}",area);
            Console.ReadLine();
        }
    }

    class DollerRupees
    {
        public void RupToDoll() //Convert Rupees To Doller
        {
            Console.WriteLine("::::::: PROGRAM : RUPEES TO DOLLER ::::::");
            Console.WriteLine("Enter Amount In RS : ");
            int rup = Convert.ToInt32(Console.ReadLine());
            double d = rup / 71;
            double doll = d;
            Console.WriteLine("{0} RS in $ is {1}",rup,doll);
            Console.ReadLine();
        }
        public void DollToRup() //Convert Doller To Rupees 
        {
            Console.WriteLine("::::::: PROGRAM : DOLLER TO RUPEES ::::::");
            Console.WriteLine("Enter Amount In $ : ");
            int doll = Convert.ToInt32(Console.ReadLine());
            double d = doll * 71;
            int rup = (int)d;
            Console.WriteLine("{0}$ in RS is {1}",doll,rup);
            Console.ReadLine();
        }
    }

    class Ascii
    {
        public void AsciiValue() //Print ASCII Values
        {
            Console.WriteLine("::::::: PROGRAM : ASCII VALUES ::::::");
            Console.WriteLine("Enter a Char : ");
            char c = Convert.ToChar(Console.ReadLine());
            int ascii = Convert.ToInt32(c);
            Console.WriteLine("Ascii value of '{0}' is : {1}",c,ascii);
            Console.ReadLine();
            Console.WriteLine("Enter a ASCII Value : ");
            int c1 = Convert.ToInt32(Console.ReadLine());
            char ascii1 = Convert.ToChar(c1);
            Console.WriteLine("Char of value {0} is : {1}",c1,ascii1);
            Console.ReadLine();
        }
    }
}
