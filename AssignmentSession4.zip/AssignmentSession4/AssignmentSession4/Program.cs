﻿using System;

namespace AssignmentSession4
{
    class Program
    {
        static void Main(string[] args)
        {
            Session4 s = new Session4();
            s.Rev50();
            s.odd();
            s.odd1();
            s.PrintTable();
            Console.ReadLine();
        }
    }

    class Session4
    {
        /// <summary>
        /// Method To Print 1 To 50 in Reverse
        /// </summary>
        public void Rev50()
        {
            Console.WriteLine(":::::::::: PROGRAM REVERSE 50 :::::::::::");
            for (int i = 50; i >=0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }

        public void odd()
        {
            Console.WriteLine(":::::::::: DO WHILE ODD NUMBERS :::::::::::");
            int i = 1;
            do
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
                i++;
            } while (i <= 50);
            Console.ReadLine();
        }
        /// <summary>
        /// Method To Print Odd Numbers
        /// </summary>
        public void odd1()
        {
            Console.WriteLine(":::::::::: FOR EACH ODD NUMBERS :::::::::::");
            int[] num = new int[50];
            for(int i = 0; i<50; i++)
            {
                num[i] = i + 1;
            }
            foreach(int t in num)
            {
                if (t % 2 != 0)
                {
                    Console.WriteLine(t);
                }
            }
            Console.ReadLine();

            Console.WriteLine(":::::::::: FOR EACH EVEN NUMBERS :::::::::::");
            foreach (int t in num)
            {
                if (t % 2 == 0)
                {
                    Console.WriteLine(t);
                }
            }
            Console.ReadLine();
        }

        public void PrintTable()
        {
            Console.WriteLine(":::::::::: PRINT TABLE :::::::::::");
            Console.WriteLine("Enter A Number : ");
            int n = Convert.ToInt32(Console.ReadLine());
            for(int i = 1; i<=10; i++)
            {
                Console.WriteLine("{0} X {1} = {2}",n,i,n*i);
            }
            Console.ReadLine();
        }


    }
}
