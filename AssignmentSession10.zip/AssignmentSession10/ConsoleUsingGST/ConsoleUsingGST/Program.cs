﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GST;

namespace ConsoleUsingGST
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Amount : ");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Gst Percent : ");
            int gst = Convert.ToInt32(Console.ReadLine());
            double Cgst;
            Gst g = new Gst();
            Console.WriteLine($"Total Amount With {gst}% GST : {g.GstCalc(amt, gst, out Cgst)}");
            Console.WriteLine($"Total GST On {amt}Rs : {Cgst}");
            Console.ReadLine();
        }
    }
}
