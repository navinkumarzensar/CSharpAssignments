﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GST
{
    public class Gst
    {
        public double GstCalc(double Amount, int Gst, out double CalcGst)
        {
            CalcGst = (Amount * Gst) / 100;
            return Amount + CalcGst;
        }
    }
}
