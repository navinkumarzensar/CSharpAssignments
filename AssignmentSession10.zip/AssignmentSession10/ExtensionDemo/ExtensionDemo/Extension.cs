﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionDemo
{
    public static class Extension
    {
        public static void IsPositiveAdd(this int n, int value)
        {
            if (n < 0)
            {
                Console.WriteLine($"Number : {n} is Negative");
            }
            else
            {
                Console.WriteLine($"Number : {n} is Positive\nAddition Is : {n + value}");
            }
        }
    }
}
