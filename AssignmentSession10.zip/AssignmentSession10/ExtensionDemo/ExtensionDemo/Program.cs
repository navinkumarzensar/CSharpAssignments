﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionDemo
{
    class Program
    {

        static void Main(string[] args)
        {
            int a = -40, b = 50;
            a.IsPositiveAdd(100);
            b.IsPositiveAdd(100);
            Console.ReadLine();
        }
    }
}
