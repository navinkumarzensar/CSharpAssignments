﻿using System;

namespace AssignmentSession3
{
    class Program
    {
        static void Main(string[] args)
        {
            Session3 s = new Session3();
            s.MajorMinor();
            s.Grades();
            s.DaysOfWeek();
            s.TerMajorMinor();
            Console.ReadLine();
        }
    }

    class Session3
    {
        /// <summary>
        /// Checks Whether A Person Is Major Or Minor
        /// </summary>
        public void MajorMinor()
        {
            Console.WriteLine(":::::::::: PROGRAM MAJOR MINOR :::::::::::");
            Console.WriteLine("Enter Age : ");
            int age = Convert.ToInt32(Console.ReadLine());
            if(age >= 18)
            {
                Console.WriteLine("Major...");
            }
            else
            {
                Console.WriteLine("Minor....");
            }
            Console.ReadLine();

        }
        /// <summary>
        /// Calculates Grade According To Percentage
        /// </summary>
        public void Grades()
        {
            Console.WriteLine(":::::::::: PROGRAM GRADE :::::::::::");
            Console.WriteLine("Enter Percentage : ");
            int per = Convert.ToInt32(Console.ReadLine());
            if (per >= 75)
            {
                Console.WriteLine("Grade : A");
            }
            else if(per >=65 && per <=74)
            {
                Console.WriteLine("Grade B");
            }
            else if (per >= 45 && per <= 64)
            {
                Console.WriteLine("Grade C");
            }
            else
            {
                Console.WriteLine("Grade D");
            }
            Console.ReadLine();
        }

        public void DaysOfWeek()
        {
            Console.WriteLine(":::::::::: PROGRAM DAYS OF WEEK :::::::::::");
            Console.WriteLine("Enter Number (1,2,3,4,5,6,7) : ");
            int d = Convert.ToInt32(Console.ReadLine());

            switch (d)
            {
                case 1:
                    Console.WriteLine("1 ::: SUNDAY");
                        break;
                case 2:
                    Console.WriteLine("2 ::: MONDAY");
                    break;
                case 3:
                    Console.WriteLine("3 ::: TUESDAY");
                    break;
                case 4:
                    Console.WriteLine("4 ::: WEDNESDAY");
                    break;
                case 5:
                    Console.WriteLine("5 ::: THURSDAY");
                    break;
                case 6:
                    Console.WriteLine("6 ::: FRIDAY");
                    break;
                case 7:
                    Console.WriteLine("7 ::: SATURDAY");
                    break;
                default:
                    Console.WriteLine("Invalid Input....");
                    break;
            }
            Console.ReadLine();
        }

        public void TerMajorMinor()
        {
            Console.WriteLine(":::::::::: PROGRAM TERNARY MAJOR MINOR :::::::::::");
            Console.WriteLine("Enter Age : ");
            int age = Convert.ToInt32(Console.ReadLine());
            string s = age >= 18 ? "Major.." : "Minor..";
            Console.WriteLine(s);
            Console.ReadLine();

        }
    }
}
