﻿using System;

namespace AssignmentSession6
{
    class Program
    {
        static void Main(string[] args)
        {
            Session6 s = new Session6();
            s.Factorial();
            s.JaggedArray();
            s.SimpleInt();
            Console.WriteLine(":::::::::::::: PROGRAM SI USING OUT :::::::::::::::");
            Console.WriteLine("Enter Principle Amt : ");
            int p = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter R% : ");
            int r = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Time : ");
            int t = Convert.ToInt32(Console.ReadLine());
            double simple;
            Console.WriteLine("Total Amount Payable is : {0}", s.TotalPayInt(p, r, t, out simple));
            Console.WriteLine("Total Intrest : {0}",simple);
            Console.ReadLine();
            Console.WriteLine(":::::::::::::: PROGRAM GST :::::::::::::::");
            Console.WriteLine("Enter Amt : ");
            int amt = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("GST Amount Payable Default : {0}",s.Gst(amt));
            Console.WriteLine("GST Amount Payable With 5% : {0}", s.Gst(amt,5));
            Console.ReadLine();
        }

        class Session6
        {
            /// <summary>
            /// Prints Factorial Of A Number
            /// </summary>
            public void Factorial()
            {
                Console.WriteLine(":::::::::::::: PROGRAM FACTORIAL :::::::::::::::");
                Console.WriteLine("Enter a Number");
                int n = Convert.ToInt32(Console.ReadLine());
                int fact=n;
                for(int i = n-1; i>=1; i--)
                {
                    fact = fact * i;
                }
                Console.WriteLine("Factorial Of {0} is : {1}",n,fact);
                Console.ReadLine();
            }

            public void JaggedArray()
            {
                Console.WriteLine(":::::::::: JAGGED ARRAY SEARCH :::::::::::");
                int[][] num = new int[2][];
                num[0] = new int[] { 1, 2, 3, 4, 5 };
                num[1] = new int[] { 6, 7, 8, 9, 10, 11, 12 };
                foreach (int t in num[0])
                {
                    Console.Write("{0}\t", t);
                }
                Console.WriteLine();
                foreach (int t in num[1])
                {
                    Console.Write("{0}\t", t);
                }
                Console.WriteLine();
                Console.WriteLine("Enter The Number To Be Searched : ");
                int n = Convert.ToInt32(Console.ReadLine());
                int f = 0;
                foreach (int t in num[0])
                {
                    if (n == t)
                    {
                        f = 1;
                    }
                }
                Console.WriteLine();
                foreach (int t in num[1])
                {
                    if (n == t)
                    {
                        f = 1;
                    }
                }
                if (f == 1)
                {
                    Console.WriteLine("Number Found.....");
                }
                else
                {
                    Console.WriteLine("Number NOT Found.....");
                }
                Console.ReadLine();
            }
            /// <summary>
            /// Calculates Simple Intrest
            /// </summary>
            public void SimpleInt()
            {
                Console.WriteLine(":::::::::::::: PROGRAM SIMPLE INTREST :::::::::::::::");
                Console.WriteLine("Enter Principle Amt : ");
                int p =Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter R : ");
                int r = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Time in Mnths : ");
                int t = Convert.ToInt32(Console.ReadLine());
                double si = (p * r * t) / 100;
                Console.WriteLine("Simple Intrest : {0}",si);
                Console.ReadLine();
            }

            public double TotalPayInt(int p,int r,int t,out double si)
            {
                double total;
                si = (p * r * t) / 100;
                total = p + si;
                return total;
            }
            /// <summary>
            /// Calculates Gst To Be Paid
            /// </summary>
            /// <param name="a">Amount</param>
            /// <param name="gst">Calculated Gst</param>
            /// <returns></returns>
            public double Gst(int a,int gst = 1)
            {
                return (a*gst)/ 100;
            }
        }
    }
}
