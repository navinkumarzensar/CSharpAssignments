﻿using System;

namespace AssignmentSession7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(":::::::::::::: PROGRAM STUDENT STRUCT :::::::::::::::");
            Console.WriteLine("Enter Roll No : ");
            int roll = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name : ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Gender (M/F) : ");
            char gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Enter Mob Number : ");
            long mobile = Convert.ToInt64(Console.ReadLine());
            Student s = new Student(roll, name, gender, mobile);
            Console.WriteLine();
            Console.WriteLine("-------- O/P --------");
            s.Display();
            Console.ReadLine();



            Console.WriteLine(":::::::::::::: PROGRAM CITIES ENUM :::::::::::::::");
            foreach (string v in Enum.GetNames(typeof(Cities)))//Printing Names
            {
                Console.WriteLine("City : {0}", v);
            }
            foreach (int v in Enum.GetValues(typeof(Cities)))//Printing City Codes
            {
                Console.WriteLine("STD CODE : {0}", v);
            }
            Console.ReadLine();
        }
    }

    struct Student
    {
        int Roll;
        string Name;
        char Gender;
        long Mobile;

        public Student(int Roll,string Name,char Gender,long Mobile)
        {
            this.Roll = Roll;
            this.Name = Name;
            this.Gender = Gender;
            this.Mobile = Mobile;
        }

        public void Display() //Method For Displaying Student Details
        {
            Console.WriteLine("Roll No : {0}",Roll);
            Console.WriteLine("Name : {0}", Name);
            Console.WriteLine("Gender : {0}", Gender);
            Console.WriteLine("Mobile Number : {0}", Mobile);
        }
    }

    enum Cities //Enums Withs City Codes
    {
        Pune=0113,Mumbai=0221,Aurangabad=0341,Banglore=0203,Nagpur=0799
    }
}
