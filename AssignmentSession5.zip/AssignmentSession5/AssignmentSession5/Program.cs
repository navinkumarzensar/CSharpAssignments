﻿
using System;

namespace AssignmentSession5
{
    class Program
    {
        static void Main(string[] args)
        {
            Session5 s = new Session5();
            s.SumSinArray();
            s.DiagSum();
            s.JaggedArray();
            s.SumOFRow();
            s.AsciiToChar();
            Console.ReadLine();
        }
    }

    class Session5
    {
        public void SumSinArray()
        {
            Console.WriteLine(":::::::::: PROGRAM SUM OF SINGLE DIM ARRAY :::::::::::");
            Console.WriteLine("Enter How Many Numbers : ");
            int n = Convert.ToInt32(Console.ReadLine());
            int[] nums = new int[n];
            Console.WriteLine("Enter {0} Values : ",n);
            int sum=0;
            for(int i = 0; i<n; i++)
            {
                nums[i] = Convert.ToInt32(Console.ReadLine());
                sum = sum + nums[i];
            }
            Console.WriteLine("Sum of Array : {0}",sum);
            Console.ReadLine();
        }

        public void DiagSum()
        {
            Console.WriteLine(":::::::::: PROGRAM SUM OF DIAG ELEMENTS :::::::::::");
            int[,] num = new int[3, 3];
            num[0, 0] = 10; num[0, 1] = 40; num[0, 2] = 50;
            num[1, 0] = 60; num[1, 1] = 20; num[1, 2] = 70;
            num[2, 0] = 80; num[2, 1] = 90; num[2, 2] = 30;
            Console.WriteLine("Given Array....");
            for (int i = 0; i<3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", num[i, j]);
                }
                Console.WriteLine();
            }
            int sum = num[0, 0] + num[1, 1] + num[2, 2];
            Console.WriteLine("Sum Of Elements Is : {0}",sum);
            Console.ReadLine();
        }

        public void JaggedArray()
        {
            Console.WriteLine(":::::::::: PROGRAM JAGGED ARRAY SEARCH :::::::::::");
            int[][] num = new int[2][];
            num[0] = new int[]{ 1, 2, 3, 4, 5 };
            num[1] = new int[] { 6, 7, 8, 9, 10, 11, 12 };
            foreach(int t in num[0])
            {
                Console.Write("{0}\t",t);
            }
            Console.WriteLine();
            foreach (int t in num[1])
            {
                Console.Write("{0}\t", t);
            }
            Console.WriteLine();
            Console.WriteLine("Enter The Number To Be Searched : ");
            int n = Convert.ToInt32(Console.ReadLine());
            int f = 0;
            foreach (int t in num[0])
            {
                if(n == t)
                {
                    f = 1;
                }
            }
            Console.WriteLine();
            foreach (int t in num[1])
            {
                if (n == t)
                {
                    f = 1;
                }
            }
            if (f == 1)
            {
                Console.WriteLine("Number Found.....");
            }
            else
            {
                Console.WriteLine("Number NOT Found.....");
            }
            Console.ReadLine();
        }

        public void SumOFRow()
        {
            Console.WriteLine(":::::::::: PROGRAM SUM OF ROWS :::::::::::");
            int[,] num = new int[3, 3];
            num[0, 0] = 10; num[0, 1] = 40; num[0, 2] = 50;
            num[1, 0] = 60; num[1, 1] = 20; num[1, 2] = 70;
            num[2, 0] = 80; num[2, 1] = 90; num[2, 2] = 30;
            Console.WriteLine("Given Array....");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", num[i, j]);
                }
                Console.WriteLine();
            }
            int s1 = num[0, 0] + num[0, 1] + num[0, 2];
            int s2 = num[1, 0] + num[1, 1] + num[1, 2];
            int s3 = num[2, 0] + num[2, 1] + num[2, 2];

            Console.WriteLine("Sum Of Rows Are : ");
            Console.WriteLine("{0}\n{1}\n{2}",s1,s2,s3);
            Console.ReadLine();
        }

        public void AsciiToChar()
        {
            Console.WriteLine(":::::::::: PROGRAM ASCII CHAR :::::::::::");
            char[,] num = new char[3, 3];
            num[0, 0] = 'a'; num[0, 1] = 'b'; num[0, 2] = 'c';
            num[1, 0] = 'd'; num[1, 1] = 'e'; num[1, 2] = 'f';
            num[2, 0] = 'g'; num[2, 1] = 'h'; num[2, 2] = 'i';
            Console.WriteLine("Char Array....");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", num[i, j]);
                }
                Console.WriteLine();
            }
            Console.WriteLine("Respective Ascii Array....");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", Convert.ToInt32(num[i, j]));
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }

    }
}
