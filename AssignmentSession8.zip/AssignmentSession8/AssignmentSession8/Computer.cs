﻿using System;

namespace AssignmentSession8
{
    /// <summary>
    /// Abstract Class With BootUp and ShutDown Methods
    /// </summary>
    public abstract class Computer
    {
        public abstract void BootUp();

        public void Shutdown()
        {
            Console.WriteLine("Computer Shutting Down.....");
        }
    }


    public class SuperComputer : Computer //Inherits Abstract Class Computer
    {
        public override void BootUp()
        {
            Console.WriteLine("SuperComputer Booting Up.....");
        }
    }

    public class MainFrameComputer : Computer //Inherits Abstract Class Computer
    {
        public override void BootUp()
        {
            Console.WriteLine("MainFrameComputer Booting Up.....");
        }
    }

    public class MicroComputer : Computer //Inherits Abstract Class Computer
    {
        public override void BootUp()
        {
            Console.WriteLine("MicroComputer Booting Up.....");
        }
    }

    public sealed class Pen //Sealed Class Pen Cannot Be Inherited
    {
        public void StartWriting()
        {
            Console.WriteLine("(Pen Class) Started Writing.....");
        }

        public void StopWriting()
        {
            Console.WriteLine("(Pen Class) Stopped Writing.....");
        }
    }
}
