﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession8
{
    /// <summary>
    /// Interface IBankAccount With Methods Deposit and Withdraw
    /// </summary>
    public interface IBankAccount
    {
        void Deposit(double amount);
        void Withdraw(double amount);

    }

    public class SavingAccount : IBankAccount //Implements IBankAccount Interface
    {
        double balance = 0;
        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Saving Deposited Amount : {amount}");
            Console.WriteLine($"Saving Balance Remaining : {balance}");
            Console.WriteLine();
        }
        public void Withdraw(double amount)
        {
            if(amount <= balance)
            {
                balance = balance - amount;
                Console.WriteLine($"Saving Withdrawed Amount : {amount}");
                Console.WriteLine($"Saving Balance Remaining : {balance}");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine($"Cannot Withdraw Amount Exceeds Balance");
                Console.WriteLine($"Saving Balance Remaining : {balance}");
            }
        }
    }
    public class CurrentAccount : IBankAccount //Implements IBankAccount Interface
    {
        double balance = 5000;
        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Current Deposited Amount : {amount}");
            Console.WriteLine($"Current Balance Remaining : {balance}");
            Console.WriteLine();
        }
        public void Withdraw(double amount)
        {
            if (amount <= balance)
            {
                balance = balance - amount;
                Console.WriteLine($"Current Withdrawed Amount : {amount}");
                Console.WriteLine($"Current Balance Remaining : {balance}");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine($"Cannot Withdraw Amount Exceeds Balance");
                Console.WriteLine($"Current Balance Remaining : {balance}");
            }
        }
    }
}
