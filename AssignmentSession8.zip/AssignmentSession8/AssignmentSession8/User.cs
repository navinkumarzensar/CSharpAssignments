﻿using System;

namespace AssignmentSession8
{
    class User
    {
        private long _id;
        private string _name, _emailid, _dateOfBirth;

        public User() //Default Constructor
        {
            Console.WriteLine("Default Constructor User Class.....");
        }
        public User(long _id, string _name, string _emailid, string _dateOfBirth) //Parameterized Constructor
        {
            Console.WriteLine("Parameterized Constructor User Class.....");
            this._id = _id;
            this._name = _name;
            this._emailid = _emailid;
            this._dateOfBirth = _dateOfBirth;
        }
        //Respective Properties
        public long Uid
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Uname
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Uemail
        {
            get { return _emailid; }
            set { _emailid = value; }
        }
        public string Udob
        {
            get { return _dateOfBirth; }
            set { _dateOfBirth = value; }
        }

        public override string ToString() //Override ToString Method
        {
            return ($"User Id : {_id}\nUser Name : {_name}\nUser Email : {_emailid}\nUser DOB : {_dateOfBirth}");
        }
    }
}
