﻿using System;

namespace AssignmentSession8
{
    class Room
    {
        private int _number, _floor, _capacity;
        private string _type;
        DateTime _bookedtime;
        private double _price;

        public Room() //Default Constructor
        {
            Console.WriteLine("Default Constructor Room Class.....");
        }

        public Room(int _number, int _floor, string _type, int _capacity, DateTime _bookedtime, double _price) //Parameterized Constructor
        {
            Console.WriteLine("Parameterized Constructor Room Class.....");
            Console.WriteLine();
            this._number = _number;
            this._floor = _floor;
            this._type = _type;
            this._capacity = _capacity;
            this._bookedtime = _bookedtime;
            this._price = _price;

        }

        //Respective Properties
        public int Rnumber
        {
            get { return _number; }
            set { _number = value; }
        }
        public int Rfloor
        {
            get { return _floor; }
            set { _floor = value; }
        }
        public string Rtype
        {
            get { return _type; }
            set { _type = value; }
        }
        public int Rcapacity
        {
            get { return _capacity; }
            set { _capacity = value; }
        }
        public DateTime Rbookedtime
        {
            get { return _bookedtime; }
            set { _bookedtime = value; }
        }
        public double Rprice
        {
            get { return _price; }
            set { _price = value; }
        }

        public override string ToString()
        {
            return ($"Room No : {_number}\nFloor No : {_floor}\nRoom Type : {_type}\nRoom Capacity : {_capacity}\nBooked Date : {_bookedtime.Date}\nRoom Price : {_price}");
        }
    }
}
