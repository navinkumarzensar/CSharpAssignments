﻿using System;
using System.Collections.Generic;

namespace AssignmentSession8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("::::::::::::::: ABSTRACT CLASS INHERITANCE DEMO ::::::::::::::::");
            Console.WriteLine("****** SUPER COMPUTER ******");
            Console.WriteLine();
            SuperComputer sc = new SuperComputer();
            sc.BootUp();
            sc.Shutdown();
            Console.WriteLine();
            Console.WriteLine("****** MAINFRAME COMPUTER ******");
            Console.WriteLine();
            MainFrameComputer mfc = new MainFrameComputer();
            mfc.BootUp();
            mfc.Shutdown();
            Console.WriteLine();
            Console.WriteLine("****** MICRO COMPUTER ******");
            Console.WriteLine();
            MicroComputer mc = new MicroComputer();
            mc.BootUp();
            mc.Shutdown();
            Console.WriteLine();
            Console.WriteLine("::::::::::::::: SEALED PEN CLASS ::::::::::::::::");
            Console.WriteLine();
            Pen p = new Pen();
            p.StartWriting();
            p.StopWriting();
            Console.WriteLine();
            Console.ReadLine();

            Console.WriteLine("::::::::::::::: PROGRAM HOTEL REQUIREMENT ::::::::::::::::");
            Console.WriteLine();
            Console.WriteLine("Enter Room No : ");
            int rnumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Floor No : ");
            int rfloor = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Room Type : ");
            string rtype = Console.ReadLine();
            Console.WriteLine("Enter Room Capacity : ");
            int rcapacity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Booked Time (YYYY/MM/DD) : ");
            DateTime rdate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter Room Price : ");
            double rprice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("******** O/P *********");
            Room r = new Room(rnumber,rfloor,rtype,rcapacity,rdate,rprice);
            Console.WriteLine(r.ToString()); //Calling Overriden ToString Method
            Console.ReadLine();

            Console.WriteLine("::::::::::::::: PROGRAM FORUM REQUIREMENT ::::::::::::::::");
            Console.WriteLine();
            List<long> ids = new List<long>();
            List<string> emails = new List<string>();
            int n=0;
            Console.WriteLine("Enter How Many Users : ");
            n = Convert.ToInt32(Console.ReadLine());
            User[] users = new User[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("************* User {0} *************",(i+1));
                Console.WriteLine("Enter ID : ");
                long Uid = Convert.ToInt64(Console.ReadLine());
                int iflag = 0;
                do //VALIDATING USER ID
                {
                    foreach (long t in ids)
                    {
                        if (t == Uid)
                        {
                            iflag = 1;
                        }
                        else
                        {
                            iflag = 0;
                        }
                    }
                    if (iflag == 1)
                    {
                        Console.WriteLine("Cannot Contain Duplicate User Id.....Enter Other");
                        Uid = Convert.ToInt64(Console.ReadLine());
                    }
                    else
                    {
                        iflag = 0;
                    }
                } while (iflag != 0);
                Console.WriteLine("Enter Name : ");
                string Uname = Console.ReadLine();
                Console.WriteLine("Enter EMAIL ID : ");
                string Uemail = Console.ReadLine();
                int eflag = 0;
                do //VALIDATING EMAIL
                {
                    foreach (string t in emails)
                    {
                        if (t == Uemail)
                        {
                            eflag = 1;
                        }
                        else
                        {
                            eflag = 0;
                        }
                    }
                    if (eflag == 1)
                    {
                        Console.WriteLine("Cannot Contain Duplicate Email.....Enter Other");
                        Uemail = Console.ReadLine();
                    }
                    else
                    {
                        eflag = 0;
                    }
                } while (eflag != 0);
                Console.WriteLine("Enter DOB (YYYY/MM/DD) : ");
                string Udob = Console.ReadLine();
                ids.Add(Uid);
                emails.Add(Uemail);
                users[i] = new User(Uid, Uname, Uemail, Udob);
            }
            foreach(Object t in users)
            {
                Console.WriteLine("****************************");
                Console.WriteLine();
                Console.WriteLine(t.ToString()); //Calling Overriden ToString Method
            }
            Console.ReadLine();

            Console.WriteLine("::::::::::::::: PROGRAM BANK REQUIREMENT ::::::::::::::::");
            Console.WriteLine();
            Console.WriteLine("************ SAVING ACCOUNT ************");
            SavingAccount sa = new SavingAccount();
            sa.Deposit(5000);
            sa.Deposit(2000);
            sa.Withdraw(4000);
            sa.Withdraw(4000);
            Console.WriteLine("************ CURRENT ACCOUNT ************");
            Console.WriteLine();
            CurrentAccount ca = new CurrentAccount();
            ca.Deposit(1000);
            ca.Deposit(1000);
            ca.Withdraw(5000);
            ca.Withdraw(2000);
            Console.ReadLine();
        }
    }
}
